import numpy as np
import scipy
import scipy.stats
import pandas as pd

filename = 'E:/udacity/project2/turnstile_data_master_with_weather.csv'
turnstile_weather = pd.read_csv(filename)
#with_rain_mean = turnstile_weather[(turnstile_weather['rain']== 1)]['ENTRIESn_hourly'].mean()
#without_rain_mean = turnstile_weather[(turnstile_weather['rain']== 0)]['ENTRIESn_hourly'].mean()
with_rain_mean = np.mean(turnstile_weather[(turnstile_weather['rain']== 1)]['ENTRIESn_hourly'])
without_rain_mean = np.mean(turnstile_weather[(turnstile_weather['rain']== 0)]['ENTRIESn_hourly'])
print with_rain_mean
print without_rain_mean
#running mannwitheyu test and retrieving values using index 0,1 first one is U value and second value is p
print scipy.stats.mannwhitneyu(turnstile_weather[(turnstile_weather['rain']== 1)]['ENTRIESn_hourly'], turnstile_weather[(turnstile_weather['rain']== 0)]['ENTRIESn_hourly'], use_continuity=True)[0]
print scipy.stats.mannwhitneyu(turnstile_weather[(turnstile_weather['rain']== 1)]['ENTRIESn_hourly'], turnstile_weather[(turnstile_weather['rain']== 0)]['ENTRIESn_hourly'], use_continuity=True)[1]