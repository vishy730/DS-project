import numpy as np
import pandas as pd
from ggplot import *
import calendar
import datetime

filename = 'E:/udacity/project2/turnstile_data_master_with_weather.csv'
turnstile_weather = pd.read_csv(filename)
#print calendar.day_name(turnstile_weather['DATEn'].weekday())


def split_groups(row):
    if row['rain'] == 0:
        return 'No Rain'
    else:
        return 'Rain'

turnstile_weather['rain_type'] = turnstile_weather.apply(split_groups, axis=1)


rain =turnstile_weather[(turnstile_weather['rain']== 1)]['ENTRIESn_hourly'] # your code here to plot a historgram for hourly entries when it is raining
no_rain = turnstile_weather[(turnstile_weather['rain']== 0)]['ENTRIESn_hourly'] # your code here to plot a historgram for hourly entries when it is not raining
#print ggplot(rain, aes(x = turnstile_weather['ENTRIESn_hourly'])) + geom_histogram(binwidth=100, fill = 'blue') + xlim(0, 8000) + ylim(0,6000)\
#+ ggtitle('Subway Usage on Rainy Days') + xlab('Number of Entries per Hour') + ylab('Frequency')

#print ggplot(no_rain, aes(x = turnstile_weather['ENTRIESn_hourly'])) + geom_histogram(binwidth=100, fill = 'red') + xlim(0, 8000) + ylim(0,6000)\
#+ ggtitle('Subway Usage on Non-Rainy Days') + xlab('Nubmer of Entries per Hour') + ylab('Frequency')

#print ggplot(turnstile_weather, aes(x = 'ENTRIESn_hourly', fill='rain_type')) + geom_histogram(binwidth=100) + xlim(0, 8000) + ylim(0,900) + ggtitle('Subway Ridership') + xlab('Entries') + ylab('Exits')

#pandas.options.mode.chained_assignment = None
#turnstile_weather.is_copy = False
#unit = turnstile_weather['UNIT'].str.replace(r'\D+', '').astype('int')
#formatted_date = pandas.to_datetime(turnstile_weather['TIMEn'])
turnstile_weather['DATEn'] = pd.to_datetime(turnstile_weather['DATEn'])
weather_day = turnstile_weather['DATEn'].dt.day
#plot = ggplot(aes('weather_day',turnstile_weather['ENTRIESn_hourly']), data = turnstile_weather) + geom_bar(stat='bar',fill='red',alpha= 0.5)  + ggtitle('Riders per day') + labs('Day of the Month','Average Entries') + xlim(0,30)
#plot = ggplot(aes(x= unit, y = turnstile_weather['EXITSn_hourly'], color = turnstile_weather['TIMEn']), data = turnstile_weather) + geom_line(color = 'red')
#plot = # your code here
plot = ggplot(aes(x = turnstile_weather[(turnstile_weather['rain']== 1)]['ENTRIESn_hourly']), data = turnstile_weather) + geom_histogram(binwidth = 100) + ggtitle('Subway Ridership on Rainy Days') + xlab('Entries') + ylab('Count')+ xlim(0,8000)
plot1 = ggplot(aes(x = turnstile_weather[(turnstile_weather['rain']== 0)]['ENTRIESn_hourly']), data = turnstile_weather) + geom_histogram(binwidth = 100) + ggtitle('Subway Ridership on Non-Rainy Days') + xlab('Entries') + ylab('Count')+ xlim(0,8000)
print plot
print plot1