import pandas as pd
import numpy as np
import scipy.stats as scist
from ggplot import *

#getting data
filename = 'E:/udacity/project2/turnstile_data_master_with_weather.csv'
turnstile_weather = pd.read_csv(filename)
#subsetting population based on rainy and non-rainy days
turnstile_weather_entry_no_rain = turnstile_weather[turnstile_weather['rain']==0]['ENTRIESn_hourly']
turnstile_weather_entry_rain = turnstile_weather[turnstile_weather['rain']==1]['ENTRIESn_hourly']
'''
#datetime = pd.DatetimeIndex(turnstile_weather['DATEn'].datetime)
#turnstile_weather['day'] = datetime.day
turnstile_weather['DATEn'] = pd.to_datetime(turnstile_weather['DATEn'])
weather_day = turnstile_weather['DATEn'].dt.day
plot = ggplot(aes('weather_day',turnstile_weather['ENTRIESn_hourly']), data = turnstile_weather) + geom_bar(stat='bar',fill='red',alpha= 0.5)  + ggtitle('Riders per day') + labs('Day','Entries') + xlim(0,30)
print plot
#mean of the two samples.
'''
mean_no_rain = np.mean(turnstile_weather[turnstile_weather['rain']==0]['ENTRIESn_hourly'])
without_rain_mean = np.mean(turnstile_weather[(turnstile_weather['rain']== 0)]['ENTRIESn_hourly'])
mean_rain = np.mean(turnstile_weather[turnstile_weather['rain']==1]['ENTRIESn_hourly'])
with_rain_mean = np.mean(turnstile_weather[(turnstile_weather['rain']== 1)]['ENTRIESn_hourly'])
median_no_rain = np.median(turnstile_weather[turnstile_weather['rain']==0]['ENTRIESn_hourly'])
median_rain = np.median(turnstile_weather[turnstile_weather['rain']==1]['ENTRIESn_hourly'])


mannu_entry = scist.mannwhitneyu(turnstile_weather_entry_no_rain,turnstile_weather_entry_rain,use_continuity=True)
print mannu_entry[0]
print mannu_entry[1]
print mean_no_rain
print without_rain_mean
print mean_rain
print with_rain_mean
print median_no_rain
print median_rain




#U = scipy.stats.mannwhitneyu(turnstile_weather[(turnstile_weather['rain']== 1)]['ENTRIESn_hourly'], turnstile_weather[(turnstile_weather['rain']== 0)]['ENTRIESn_hourly'], use_continuity=True)[0]
#p = scipy.stats.mannwhitneyu(turnstile_weather[(turnstile_weather['rain']== 1)]['ENTRIESn_hourly'], turnstile_weather[(turnstile_weather['rain']== 0)]['ENTRIESn_hourly'], use_continuity=True)[1]
