import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

filename = 'E:/udacity/project2/turnstile_data_master_with_weather.csv'
turnstile_weather = pd.read_csv(filename)
no_rain = turnstile_weather[turnstile_weather['rain']== 0]
#print no_rain
turnstile_weather[(turnstile_weather['rain']== 1)]['ENTRIESn_hourly'].hist()
turnstile_weather[(turnstile_weather['rain']== 0)]['ENTRIESn_hourly'].hist()
plt.show()
